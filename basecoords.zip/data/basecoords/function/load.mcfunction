scoreboard objectives add base trigger
