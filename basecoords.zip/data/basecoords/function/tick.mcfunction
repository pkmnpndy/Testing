execute as @a[scores={base=1..}] run tellraw @s "Base: 2500 -300"
scoreboard players set @a[scores={base=1..}] base 0
scoreboard players enable @a base
